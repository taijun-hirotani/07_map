//****************************************************************************************
// BingMaps&BmapQuery 
//****************************************************************************************
//Init
function GetMap(){
    //------------------------------------------------------------------------
    //1. Instance
    //------------------------------------------------------------------------
        const map = new Bmap("#myMap");
    
    //------------------------------------------------------------------------
    //2. geolocation: Display Map
    //   map.geolocation(function(data:object){...});
    //------------------------------------------------------------------------
        map.geolocation(function(data) {
            //location
            const lat = data.coords.latitude;
            const lon = data.coords.longitude;
            //Map
            map.startMap(lat, lon, "load", 10);
            //alert("地図表示");
            //Pin
            map.pin(lat,lon,"#ff0000");
        });
    }



//*****************************************************
// Click Event
// ぐるなびAPIへデータRequest → APIサーバーからresponseデータ取得
//*****************************************************
$("#btn").on("click", function() {
    //送信データをObject変数で用意
    //参考URL:https://api.gnavi.co.jp/api/manual/restsearch/
            const data = {
                keyid:$("#key").val(),
                latitude:$("#lat").val(),
                longitude:$("#lon").val(),
                range:3
            };
            //Ajax（非同期通信）
            axios.get('https://api.gnavi.co.jp/RestSearchAPI/v3/', {
                params:data
            })
                .then(function (response) {
                //データ受信成功！！showData関数にデータを渡す
                showData(response.data);
            }).catch(function (error) {
                console.log(error);//通信Error
            }).then(function () {
                //console.log("Last");//通信OK/Error後に処理を必ずさせたい場合
            });
            
        });
    




    //*****************************************************
    //ぐるなびデータ表示処理
    //*****************************************************
    
    function showData(data){
        //データ確認用
        console.log(data.rest[0]);
        //alert("データ受信");
        //データを繰り返し処理で取得
        const len  = data.rest.length; //データ数を取得
        console.log("データ数"+len);

            // const options = [];
            // console.log(options);
            // options[0] = {
            //     "lat": data.rest[0].latitude,
            //     "lon": data.rest[0].longitude,
            //     "title": data.rest[0].name,
            //     "pinColor": "#ff0000",
            //     "height": 300,
            //     "width": 320,
            //     "description": data.rest[0].image_url,
            //     "show": true
            // };
            // map.infoboxLayers(options, false);

            const options=[];
            for( let i=0; i<len; i++){
            const address= data.rest[i].address
            const lat2 = data.rest[i].latitude;
            const lon2 = data.rest[i].longitude;
            $("#table").append('<tr><td>' + data.rest[i].name + '</td><td>'+ address + '</td></tr>');//店舗情報 店名/住所

            console.log(options);
            options[i] = {
                "lat": data.rest[i].latitude,
                "lon": data.rest[i].longitude,
                "title": data.rest[i].name,
                "pinColor": "#ff0000",
                "height": 300,
                "width": 320,
                "show": true
            };
            map.infoboxLayers(options, false);
            
            
            //各店舗の緯度経度を取得後、ピン立てる
            // const map = new Bmap("#myMap");
            // map.geolocation(function(data){
            // //alert(lat2+"/"+lon2);//←ここまで表示
            // map.startMap(lat2, lon2, "load", 15);//移動は出来た
            // map.pin(lat2,lon2,"#ff0000");//←ここ表示されない
            // alert("ピン刺さって")
            // });
        };
    }